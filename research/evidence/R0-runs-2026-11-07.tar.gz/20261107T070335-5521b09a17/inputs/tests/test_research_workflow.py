"""Offline contract tests: corrupted evidence must never unlock another stage."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from src.research_workflow import Workflow, WorkflowError, confined, load_json, write_json


class WorkflowTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "research/plans").mkdir(parents=True)
        (self.root / "input.txt").write_text("source input\n", encoding="utf-8")
        (self.root / "report.md").write_text("Engineering smoke report.\n", encoding="utf-8")
        self.registry = {"schema_version": 1, "stages": [
            {"id": "R0", "depends_on": [], "plan": "research/plans/R0.json", "kind": "engineering"},
            {"id": "R1", "depends_on": ["R0"], "plan": "research/plans/R1.json", "kind": "science"},
        ]}
        write_json(self.root / "research/stages.json", self.registry)
        self.plan = {
            "schema_version": 1, "stage_id": "R0", "question": "Does the ledger work?",
            "scope": "Offline engineering verification", "budget": {"max_wall_seconds": 20},
            "tasks": [{"id": "smoke", "argv": ["{python}", "-c", "from pathlib import Path; Path('answer.txt').write_text('42'); print('recorded')"],
                       "inputs": ["input.txt"], "outputs": ["answer.txt"], "timeout_seconds": 10}],
            "exit_criteria": [{"id": "C1", "description": "Output exists with intact evidence", "task_ids": ["smoke"]}],
            "predictions": [{"id": "P1", "statement": "Offline task succeeds"}],
        }
        self.save_plan()
        self.workflow = Workflow(self.root)

    def save_plan(self) -> None:
        write_json(self.root / "research/plans/R0.json", self.plan)

    def run_smoke(self) -> Path:
        result = self.workflow.run("R0")
        return self.workflow.attempt("R0", result["attempt_id"])

    def accepted_review(self, attempt: Path, stage: str = "R0") -> Path:
        review = self.workflow.review_template(stage, "report.md", attempt.name)
        review["reviewer"].update(name="test reviewer", harness="offline-test")
        review["criteria"][0].update(verdict="pass", evidence=["smoke/answer.txt"])
        review["predictions"][0].update(outcome="Observed", evidence=["smoke/answer.txt"])
        review.update(verdict="accept", limitations=["Engineering test only; no scientific finding"])
        path = self.root / "scored-review.json"
        write_json(path, review)
        return path

    def test_complete_run_review_close_unlocks_next_without_scientific_approval(self) -> None:
        self.assertEqual(self.workflow.next_stage()["next"]["id"], "R0")
        attempt = self.run_smoke()
        self.assertEqual((attempt / "inputs/input.txt").read_text(encoding="utf-8"), "source input\n")
        result = self.workflow.verify("R0")
        self.assertGreaterEqual(result["checked_files"], 3)
        self.workflow.review("R0", self.accepted_review(attempt), attempt.name)
        self.workflow.close("R0", attempt.name)
        self.assertEqual(self.workflow.verify_closure("R0")["scientific_validity"], "not_assessed")
        self.assertEqual(self.workflow.next_stage()["next"]["id"], "R1")
        with self.assertRaisesRegex(WorkflowError, "not authorized"):
            self.workflow.run("R1")

    def test_changed_output_cannot_verify_or_close(self) -> None:
        attempt = self.run_smoke()
        (attempt / "tasks/smoke/answer.txt").write_text("altered", encoding="utf-8")
        with self.assertRaisesRegex(WorkflowError, "Output changed"):
            self.workflow.verify("R0")

    def test_missing_output_is_failed_attempt_with_logs_and_manifest(self) -> None:
        self.plan["tasks"][0]["outputs"] = ["missing.txt"]
        self.save_plan()
        with self.assertRaisesRegex(WorkflowError, "evidence retained"):
            self.workflow.run("R0")
        attempt = self.workflow.attempt("R0")
        manifest = load_json(attempt / "manifest.json")
        self.assertEqual(manifest["status"], "failed")
        self.assertEqual(manifest["tasks"][0]["exit_code"], 0)
        self.assertTrue((attempt / "tasks/smoke/stdout.log").is_file())
        self.assertFalse((self.root / ".research/workflow/active.lock").exists())

    def test_failed_exit_is_retained_and_not_reused(self) -> None:
        self.plan["tasks"][0]["argv"] = ["{python}", "-c", "raise SystemExit(7)"]
        self.save_plan()
        with self.assertRaises(WorkflowError):
            self.workflow.run("R0")
        first = self.workflow.attempt("R0")
        self.assertEqual(load_json(first / "manifest.json")["tasks"][0]["exit_code"], 7)
        with self.assertRaises(WorkflowError):
            self.workflow.run("R0")
        self.assertEqual(len(list(first.parent.glob("*/manifest.json"))), 2)

    def test_timeout_stops_task_and_records_failure(self) -> None:
        self.plan["tasks"][0].update(argv=["{python}", "-c", "import time; time.sleep(20)"], timeout_seconds=0.15)
        self.save_plan()
        with self.assertRaises(WorkflowError):
            self.workflow.run("R0")
        record = load_json(self.workflow.attempt("R0") / "manifest.json")["tasks"][0]
        self.assertTrue(record["timed_out"])

    def test_live_source_change_requires_rerun_but_history_still_verifies(self) -> None:
        attempt = self.run_smoke()
        (self.root / "input.txt").write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(WorkflowError, "Live input changed"):
            self.workflow.verify("R0")
        self.assertTrue(self.workflow.verify("R0", attempt.name, live_sources=False)["verified"])
        (attempt / "inputs/input.txt").write_text("corrupt snapshot", encoding="utf-8")
        with self.assertRaisesRegex(WorkflowError, "snapshot changed"):
            self.workflow.verify("R0", attempt.name, live_sources=False)

    def test_review_cannot_approve_an_edited_report(self) -> None:
        attempt = self.run_smoke()
        review_path = self.accepted_review(attempt)
        (self.root / "report.md").write_text("New conclusion", encoding="utf-8")
        with self.assertRaisesRegex(WorkflowError, "report changed"):
            self.workflow.review("R0", review_path)

    def test_review_must_score_registered_criteria_and_cite_outputs(self) -> None:
        attempt = self.run_smoke()
        path = self.accepted_review(attempt)
        review = load_json(path)
        review["criteria"][0]["evidence"] = ["unregistered/file.txt"]
        write_json(path, review)
        with self.assertRaisesRegex(WorkflowError, "registered output evidence"):
            self.workflow.review("R0", path)
        review["criteria"] = []
        write_json(path, review)
        with self.assertRaisesRegex(WorkflowError, "every registered criteria"):
            self.workflow.review("R0", path)

    def test_stage_dependencies_cannot_be_skipped(self) -> None:
        self.registry["stages"][1]["execution_authorized"] = True
        write_json(self.root / "research/stages.json", self.registry)
        workflow = Workflow(self.root)
        with self.assertRaisesRegex(WorkflowError, "Dependency is not closed"):
            workflow.run("R1")

    def test_duplicate_matrix_empty_outputs_and_path_escape_are_rejected(self) -> None:
        self.plan["tasks"].append(self.plan["tasks"][0].copy())
        self.save_plan()
        with self.assertRaisesRegex(WorkflowError, "Duplicate task"):
            self.workflow.validate_plan("R0")
        self.plan["tasks"].pop()
        self.plan["tasks"][0]["outputs"] = []
        self.save_plan()
        with self.assertRaisesRegex(WorkflowError, "nonempty outputs"):
            self.workflow.validate_plan("R0")
        with self.assertRaises(WorkflowError):
            confined(self.root, "../outside.txt")

    def test_lock_prevents_duplicate_execution(self) -> None:
        with self.workflow.lock("R0"):
            with self.assertRaisesRegex(WorkflowError, "lock exists"):
                self.workflow.run("R0")

    def test_registry_cycles_and_symlink_inputs_are_rejected(self) -> None:
        self.registry["stages"][0]["depends_on"] = ["R1"]
        write_json(self.root / "research/stages.json", self.registry)
        with self.assertRaisesRegex(WorkflowError, "cycle"):
            Workflow(self.root)
        link = self.root / "shortcut.txt"
        try:
            link.symlink_to(self.root / "input.txt")
        except OSError:
            return  # Windows without symlink privilege still tests lexical confinement above.
        with self.assertRaisesRegex(WorkflowError, "Symlinks"):
            confined(self.root, "shortcut.txt", must_exist=True)

    def test_closed_record_hash_tampering_is_detected(self) -> None:
        attempt = self.run_smoke()
        self.workflow.review("R0", self.accepted_review(attempt))
        self.workflow.close("R0")
        review_path = attempt / "review.json"
        review = load_json(review_path)
        review["limitations"].append("unrecorded edit")
        write_json(review_path, review)
        with self.assertRaisesRegex(WorkflowError, "Closed evidence changed"):
            self.workflow.verify_closure("R0")

    def test_retry_cap_counts_interrupted_attempt_directories(self) -> None:
        self.plan["budget"]["max_attempts"] = 1
        self.save_plan()
        interrupted = self.root / "artifacts/research/R0/interrupted"
        interrupted.mkdir(parents=True)
        with self.assertRaisesRegex(WorkflowError, "max_attempts exhausted"):
            self.workflow.run("R0")
        self.assertEqual(len(list(interrupted.parent.iterdir())), 1)

    def test_cumulative_wall_budget_counts_previous_failed_runs(self) -> None:
        self.plan["budget"]["total_wall_seconds"] = 2
        self.save_plan()
        write_json(self.root / "artifacts/research/R0/previous/manifest.json",
                   {"elapsed_seconds": 2.1, "status": "failed"})
        with self.assertRaisesRegex(WorkflowError, "total_wall_seconds exhausted"):
            self.workflow.run("R0")

    def test_finite_budgets_and_secret_input_guards(self) -> None:
        for value in (float("inf"), float("nan"), True, -1):
            self.plan["budget"]["max_wall_seconds"] = value
            # JSON intentionally permits these invalid external values for validation.
            (self.root / "research/plans/R0.json").write_text(json.dumps(self.plan), encoding="utf-8")
            with self.assertRaisesRegex(WorkflowError, "max_wall_seconds"):
                self.workflow.validate_plan("R0")
        self.plan["budget"]["max_wall_seconds"] = 20
        for value in (".env", ".env.local", ".git/config", ".venv/pyvenv.cfg"):
            target = self.root / value
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("test-only dummy content", encoding="utf-8")
            self.plan["tasks"][0]["inputs"] = [value]
            self.save_plan()
            with self.assertRaisesRegex(WorkflowError, "cannot be snapshotted"):
                self.workflow.validate_plan("R0")

    def test_historical_closure_checks_frozen_report_and_binds_review(self) -> None:
        attempt = self.run_smoke()
        self.workflow.review("R0", self.accepted_review(attempt))
        self.workflow.close("R0")
        (self.root / "report.md").unlink()
        self.assertEqual(self.workflow.verify_closure("R0")["status"], "operationally_closed")
        (attempt / "report.md").write_text("corrupt", encoding="utf-8")
        self.assertEqual(self.workflow.status()["stages"][0]["state"], "invalid")
        self.assertEqual(self.workflow.status()["stages"][1]["state"], "waiting")

    def test_keyboard_interrupt_terminates_owned_process_tree(self) -> None:
        child = MagicMock()
        child.wait.side_effect = [KeyboardInterrupt(), 0]
        child.poll.return_value = None
        child.returncode = -9
        with patch("src.research_workflow.subprocess.Popen", return_value=child), \
             patch("src.research_workflow.subprocess.run") as runner, \
             patch("src.research_workflow.os.killpg", create=True) as killpg:
            with self.assertRaises(KeyboardInterrupt):
                self.workflow._execute(["unused"], self.root, 10)
            import os
            if os.name == "nt":
                self.assertEqual(runner.call_args.args[0][0], "taskkill")
            else:
                killpg.assert_called_once()
            self.assertEqual(child.wait.call_count, 2)

    def setup_three_stage_chain(self) -> None:
        self.registry["stages"][1]["execution_authorized"] = True
        self.registry["stages"].append({"id": "R2", "depends_on": ["R1"],
                                        "plan": "research/plans/R2.json", "kind": "science",
                                        "execution_authorized": True})
        write_json(self.root / "research/stages.json", self.registry)
        for stage in ("R1", "R2"):
            plan = dict(self.plan, stage_id=stage, status="frozen")
            write_json(self.root / f"research/plans/{stage}.json", plan)
        self.workflow = Workflow(self.root)

    def close_chain_stage(self, stage: str) -> Path:
        result = self.workflow.run(stage)
        attempt = self.workflow.attempt(stage, result["attempt_id"])
        self.workflow.review(stage, self.accepted_review(attempt, stage), attempt.name)
        self.workflow.close(stage, attempt.name)
        return attempt

    def test_corrupt_ancestor_invalidates_descendant_closure_and_blocks_third_stage(self) -> None:
        self.setup_three_stage_chain()
        first = self.close_chain_stage("R0")
        second = self.close_chain_stage("R1")
        dependency_hashes = load_json(second / "manifest.json")["dependency_closure_hashes"]
        self.assertEqual(set(dependency_hashes), {"R0"})
        self.assertEqual(load_json(self.workflow.closure_path("R1"))["dependency_closure_hashes"], dependency_hashes)
        (first / "tasks/smoke/answer.txt").write_text("corrupted ancestor", encoding="utf-8")
        states = {row["id"]: row["state"] for row in self.workflow.status()["stages"]}
        self.assertEqual(states, {"R0": "invalid", "R1": "invalid", "R2": "waiting"})
        with self.assertRaisesRegex(WorkflowError, "Output changed"):
            self.workflow.run("R2")

    def test_dependency_closure_swap_is_rejected_even_if_ancestor_still_valid(self) -> None:
        self.setup_three_stage_chain()
        self.close_chain_stage("R0")
        self.close_chain_stage("R1")
        path = self.workflow.closure_path("R0")
        closure = load_json(path)
        closure["closed_at"] = "changed after downstream acceptance"
        write_json(path, closure)
        self.assertEqual(self.workflow.verify_closure("R0")["status"], "operationally_closed")
        with self.assertRaisesRegex(WorkflowError, "Dependency closure changed"):
            self.workflow.verify_closure("R1")
        with self.assertRaisesRegex(WorkflowError, "Dependency closure changed"):
            self.workflow.run("R2")

    def test_dependency_closure_swap_between_execution_and_review_is_rejected(self) -> None:
        self.setup_three_stage_chain()
        self.close_chain_stage("R0")
        result = self.workflow.run("R1")
        attempt = self.workflow.attempt("R1", result["attempt_id"])
        review_path = self.accepted_review(attempt, "R1")
        path = self.workflow.closure_path("R0")
        closure = load_json(path)
        closure["closed_at"] = "swapped during downstream review"
        write_json(path, closure)
        with self.assertRaisesRegex(WorkflowError, "Dependency closure changed"):
            self.workflow.review("R1", review_path, attempt.name)


if __name__ == "__main__":
    unittest.main()
