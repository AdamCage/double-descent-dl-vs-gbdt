"""Integrity gates for future claims; all approvals below are test fixtures."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from src.research_claims import validate_claims


def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class ClaimGateTest(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        (self.root / "metrics.json").write_bytes(b'{"loss":0.1}\n')
        self.evidence = [{"path": "metrics.json", "sha256": sha((self.root / "metrics.json").read_bytes())}]
        self.statement = "Fixture measured loss is 0.1."
        self.decision = {
            "claim_id": "fixture-claim",
            "statement_sha256": sha(self.statement.encode("utf-8")),
            "evidence": copy.deepcopy(self.evidence),
            "reviewer": "test-reviewer-label",
            "harness": "codex",
            "verdict": "accepted",
        }
        self.claim = {
            "id": "fixture-claim", "statement": self.statement,
            "scope": {"dataset": "unit test fixture only"},
            "limitations": ["Not real research evidence"],
            "evidence": copy.deepcopy(self.evidence),
        }
        self.doc = {"schema_version": 1, "claims": [self.claim]}
        self.save_decision()

    def save_decision(self, raw: bytes | None = None):
        target = self.root / "decision.json"
        target.write_bytes(raw if raw is not None else json.dumps(self.decision).encode("utf-8"))
        self.claim["scientific_review"] = {"path": "decision.json", "sha256": sha(target.read_bytes())}

    def test_exact_bound_decision_is_accepted_mechanically(self):
        self.assertEqual(validate_claims(self.root, self.doc), [])
        self.decision["harness"] = "human"
        self.save_decision()
        self.assertEqual(validate_claims(self.root, self.doc), [])

    def test_empty_claim_registry_needs_no_synthetic_approval(self):
        self.assertEqual(validate_claims(self.root, {"schema_version": 1, "claims": []}), [])

    def test_changed_statement_cannot_reuse_review(self):
        self.claim["statement"] += " Broader conclusion."
        self.assertTrue(any("statement_sha256 mismatch" in issue for issue in validate_claims(self.root, self.doc)))

    def test_changed_evidence_bytes_are_rejected(self):
        (self.root / "metrics.json").write_bytes(b'{"loss":0.01}\n')
        self.assertTrue(any("SHA-256 mismatch" in issue for issue in validate_claims(self.root, self.doc)))

    def test_changed_decision_bytes_are_rejected(self):
        (self.root / "decision.json").write_bytes(b'{}')
        self.assertTrue(any("scientific_review: SHA-256 mismatch" in issue for issue in validate_claims(self.root, self.doc)))

    def test_decision_cannot_approve_different_or_partial_evidence(self):
        (self.root / "other.json").write_bytes(b"other evidence")
        self.decision["evidence"] = [{"path": "other.json", "sha256": sha(b"other evidence")}]
        self.save_decision()
        self.assertTrue(any("match exact" in issue for issue in validate_claims(self.root, self.doc)))

    def test_cursor_and_missing_reviewer_cannot_grant_scientific_approval(self):
        for field, value in (("harness", "cursor"), ("harness", ["codex"]),
                             ("reviewer", " "), ("verdict", "proposed"),
                             ("claim_id", "different-claim")):
            with self.subTest(field=field, value=value):
                saved = self.decision[field]
                self.decision[field] = value
                self.save_decision()
                self.assertTrue(validate_claims(self.root, self.doc))
                self.decision[field] = saved

    def test_missing_statement_scope_or_limitations_is_rejected(self):
        for field in ("statement", "scope", "limitations", "evidence", "scientific_review"):
            with self.subTest(field=field):
                doc = copy.deepcopy(self.doc)
                del doc["claims"][0][field]
                self.assertTrue(validate_claims(self.root, doc))

    def test_malformed_user_json_returns_diagnostics(self):
        for value in (None, [], "text", {}, {"schema_version": True, "claims": []},
                      {"schema_version": 1, "claims": {}},
                      {"schema_version": 1, "claims": [None, [], {"id": []}]},
                      {"schema_version": 1, "claims": [{"evidence": [None, [], {"path": []}]}]}):
            with self.subTest(value=value):
                self.assertTrue(validate_claims(self.root, value))
        self.assertTrue(validate_claims(None, self.doc))

    def test_invalid_decision_json_is_rejected(self):
        for raw in (b"not json", b"[]", b'{"verdict":"accepted","verdict":"rejected"}',
                    b'{"metric":NaN}', b"\xff"):
            with self.subTest(raw=raw):
                self.save_decision(raw)
                self.assertTrue(validate_claims(self.root, self.doc))

    def test_lone_surrogates_return_diagnostics(self):
        self.claim["statement"] = "\ud800"
        self.assertTrue(validate_claims(self.root, self.doc))
        self.claim["statement"] = self.statement
        self.claim["evidence"][0]["path"] = "\ud800"
        self.assertTrue(validate_claims(self.root, self.doc))

    def test_duplicate_ids_and_duplicate_evidence_are_rejected(self):
        self.doc["claims"].append(copy.deepcopy(self.claim))
        self.assertTrue(any("duplicate claim id" in issue for issue in validate_claims(self.root, self.doc)))
        self.doc["claims"].pop()
        self.claim["evidence"].append(copy.deepcopy(self.evidence[0]))
        self.assertTrue(any("duplicate evidence" in issue for issue in validate_claims(self.root, self.doc)))

    def test_absolute_parent_and_drive_relative_paths_are_rejected(self):
        for path in ("../outside.json", str(self.root / "metrics.json"), "C:metrics.json",
                     "\\\\server\\share\\metrics.json", "/etc/passwd", "\x00"):
            with self.subTest(path=path):
                self.claim["evidence"] = [{"path": path, "sha256": "0" * 64}]
                self.assertTrue(validate_claims(self.root, self.doc))

    def test_symlink_outside_repository_is_rejected(self):
        with tempfile.TemporaryDirectory() as outside:
            target = Path(outside) / "outside.json"
            target.write_bytes(b"outside")
            link = self.root / "linked.json"
            try:
                link.symlink_to(target)
            except (OSError, NotImplementedError) as error:
                self.skipTest(f"symlink creation unavailable: {error}")
            self.claim["evidence"] = [{"path": "linked.json", "sha256": sha(b"outside")}]
            self.assertTrue(any("escapes" in issue for issue in validate_claims(self.root, self.doc)))


if __name__ == "__main__":
    unittest.main()
