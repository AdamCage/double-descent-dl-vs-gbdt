Review the current stage from its frozen plan and exact attempt artifacts.
Run scripts/research.py verify first. Check all registered tasks, failed runs,
predictions, exit criteria, deviations and evidence. Prepare structured review
using the CLI and record reviewer identity/harness honestly. Revise or reject
when evidence is missing. A Cursor review is operational, not independent
scientific endorsement. Update REPORT/HANDOFF and close only after checks pass.
