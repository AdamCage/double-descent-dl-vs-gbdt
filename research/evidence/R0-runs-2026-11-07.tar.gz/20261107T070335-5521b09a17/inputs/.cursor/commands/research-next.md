Read AGENTS.md, research/STATE.md, docs/automation.md, and the current stage
packet. Run `uv run python scripts/research.py status` and `next`.
Continue the next authorized stage autonomously through plan, bounded execution,
verification, operational review, report, closure and handoff. Stop on a real
scientific decision, exhausted budget, integrity failure or unauthorized stage.
Do not start R1–R7 while execution_authorized=false. Record the precise reason
and proposed next action; never mark an unexecuted stage complete.
