---
name: stage-close
description: Close an operational stage and hand off without overstating science.
---

Follow docs/automation.md. Freeze scored review; close only when all registered
criteria pass. Preserve scientific_validity=not_assessed. Export and verify an
evidence bundle, recording its digest and closure reference. Update HANDOFF and
research/STATE.md with exact next command, failures, budget and unresolved
questions. Continue the next authorized stage autonomously within accepted
design. New scientific decisions go to human/Codex with evidence, not fake
actor labels or approval. Do not promote empirical paper claims without a
separate bound scientific decision in research/claims.json.
