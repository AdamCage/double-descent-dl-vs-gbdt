---
name: stage-kickoff
description: Prepare and freeze an authorized double-descent research stage before execution.
---

Read AGENTS.md, research/STATE.md and docs/automation.md. Inspect status/next.
Check the stage is authorized and dependencies verified. Fill PLAN.md and JSON
from research/templates; identify scientific decision reference, hypotheses,
falsifiers, discovery exposure, data/split/noise/seed rules, task matrix,
artifacts, convergence/interpolation, criteria and finite retry/time/resource
budgets. Declare every transitive source/input file. Freeze before results.
Run validate-plan. If a scientific decision is missing, prepare a concrete
proposal for human/Codex and continue independent technical work.
