---
name: stage-review
description: Review every registered criterion against exact research artifacts.
---

Run verify, then read frozen plan, raw evidence and source snapshots. Check
matrix completeness, provenance, convergence, interpolation brackets, held-out
exposure, exclusions, uncertainty and competing explanations. Fill REPORT.md
and prepare structured review with CLI. Score every criterion and prediction
using exact task/output paths; state limitations and reviewer identity/harness
honestly. Self-review is not independent review. A valid bound review is an
operational assessment, never human/Codex scientific endorsement. Record revise
or reject when requirements fail; preserve it and use a new attempt for fixes.
