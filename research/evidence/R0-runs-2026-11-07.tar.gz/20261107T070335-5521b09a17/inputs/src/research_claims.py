"""Validate exact claim/evidence/decision bindings for paper-supporting claims.

This is a local integrity gate, not authentication. ``reviewer`` and ``harness``
are logical labels supplied by the caller; this code cannot prove identity,
independence, scientific correctness, or that a human/Codex actually reviewed.
Every entry in ``claims`` is treated as paper-supporting. Draft proposals belong
outside that accepted-claim registry until their separate decision exists.
Statement digests cover exact UTF-8 bytes, without whitespace normalization.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
from typing import Any

_SHA256 = re.compile(r"[0-9a-f]{64}\Z")


def _text(value: Any) -> bool:
    return type(value) is str and bool(value.strip())


def _sha256(value: Any) -> bool:
    return type(value) is str and _SHA256.fullmatch(value) is not None


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _bound_file(root: Path, binding: Any, label: str,
                problems: list[str]) -> Path | None:
    if type(binding) is not dict or set(binding) != {"path", "sha256"}:
        problems.append(f"{label}: expected exactly path and sha256")
        return None
    raw_path, expected = binding["path"], binding["sha256"]
    if not _text(raw_path) or not _sha256(expected):
        problems.append(f"{label}: nonempty relative path and lowercase SHA-256 required")
        return None
    # Reject both platform syntaxes, including C:drive-relative paths and UNC.
    if PurePosixPath(raw_path).is_absolute() or PureWindowsPath(raw_path).drive \
            or PureWindowsPath(raw_path).root:
        problems.append(f"{label}: path must be relative to the repository")
        return None
    try:
        path = (root / raw_path).resolve(strict=True)
        if not path.is_relative_to(root) or not path.is_file():
            problems.append(f"{label}: path escapes the repository or is not a file")
            return None
        if _digest(path) != expected:
            problems.append(f"{label}: SHA-256 mismatch")
            return None
    except (OSError, ValueError, UnicodeError, RuntimeError) as error:
        problems.append(f"{label}: cannot read bound file ({type(error).__name__})")
        return None
    return path


def _evidence(root: Path, value: Any, label: str,
              problems: list[str]) -> list[dict] | None:
    if type(value) is not list or not value:
        problems.append(f"{label}: nonempty evidence list required")
        return None
    bindings, seen = [], set()
    invalid = False
    for index, binding in enumerate(value):
        if _bound_file(root, binding, f"{label}[{index}]", problems) is None:
            invalid = True
            continue
        path = binding["path"]
        if path in seen:
            problems.append(f"{label}: duplicate evidence path {path!r}")
            invalid = True
        seen.add(path)
        bindings.append(dict(binding))
    return None if invalid else bindings


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate decision JSON key")
        value[key] = item
    return value


def _invalid_number(value: str) -> None:
    raise ValueError(f"non-finite decision JSON number: {value}")


def validate_claims(root: Path, claims_doc: Any) -> list[str]:
    """Return diagnostics for malformed or unbound claims; never approve science.

    The function performs only file reads, accepts already parsed JSON, and
    returns malformed-input diagnostics rather than raising validation errors.
    Bound decision JSON requires ``claim_id``, ``statement_sha256``, ``evidence``,
    ``reviewer``, ``harness`` (human/codex), and ``verdict`` (accepted).
    """
    problems: list[str] = []
    try:
        root = Path(root).resolve(strict=True)
        if not root.is_dir():
            return ["claims: repository root is not a directory"]
    except (TypeError, OSError, ValueError, UnicodeError, RuntimeError):
        return ["claims: invalid repository root"]
    if type(claims_doc) is not dict:
        return ["claims: document must be an object"]
    if type(claims_doc.get("schema_version")) is not int or claims_doc["schema_version"] != 1:
        problems.append("claims: schema_version must be 1")
    claims = claims_doc.get("claims")
    if type(claims) is not list:
        return problems + ["claims: claims must be a list"]
    seen_ids = set()
    for index, claim in enumerate(claims):
        label = f"claim[{index}]"
        if type(claim) is not dict:
            problems.append(f"{label}: claim must be an object")
            continue
        claim_id = claim.get("id")
        if not _text(claim_id):
            problems.append(f"{label}: nonempty id required")
        else:
            label = f"claim {claim_id!r}"
            if claim_id in seen_ids:
                problems.append(f"{label}: duplicate claim id")
            seen_ids.add(claim_id)
        statement = claim.get("statement")
        if not _text(statement):
            problems.append(f"{label}: nonempty statement required")
        scope = claim.get("scope")
        if not (_text(scope) or (type(scope) is dict and bool(scope)
                                and all(_text(key) for key in scope))):
            problems.append(f"{label}: nonempty scope string or object required")
        limitations = claim.get("limitations")
        if type(limitations) is not list or not limitations \
                or not all(_text(item) for item in limitations):
            problems.append(f"{label}: nonempty list of limitations required")
        evidence = _evidence(root, claim.get("evidence"), f"{label} evidence", problems)
        decision_path = _bound_file(root, claim.get("scientific_review"),
                                    f"{label} scientific_review", problems)
        if decision_path is None:
            continue
        try:
            decision = json.loads(decision_path.read_text(encoding="utf-8"),
                                  object_pairs_hook=_unique_object,
                                  parse_constant=_invalid_number)
        except (OSError, ValueError, UnicodeError, RecursionError) as error:
            problems.append(f"{label}: invalid decision JSON ({type(error).__name__})")
            continue
        if type(decision) is not dict:
            problems.append(f"{label}: scientific decision must be an object")
            continue
        if not _text(claim_id) or decision.get("claim_id") != claim_id:
            problems.append(f"{label}: decision claim_id mismatch")
        try:
            statement_digest = hashlib.sha256(statement.encode("utf-8")).hexdigest() \
                if _text(statement) else None
        except UnicodeError:
            statement_digest = None
        if statement_digest is None or decision.get("statement_sha256") != statement_digest:
            problems.append(f"{label}: decision statement_sha256 mismatch")
        if decision.get("verdict") != "accepted":
            problems.append(f"{label}: scientific decision verdict must be accepted")
        if decision.get("harness") not in ("human", "codex"):
            problems.append(f"{label}: scientific decision harness must be human or codex")
        if not _text(decision.get("reviewer")):
            problems.append(f"{label}: scientific decision reviewer required")
        decision_evidence = _evidence(root, decision.get("evidence"),
                                     f"{label} decision evidence", problems)
        if evidence is not None and decision_evidence is not None:
            expected = {item["path"]: item["sha256"] for item in evidence}
            actual = {item["path"]: item["sha256"] for item in decision_evidence}
            if actual != expected:
                problems.append(f"{label}: decision evidence must match exact claim path/hash bindings")
    return problems
