# R1 legacy audit

Descriptive audit. `scientific_validity=not_assessed`.

## LEG-MLP-ROUNDED-LOG

The preserved s05 log prints train_loss=0.0000 and train_acc=1.000 for the completed widths. Those are rounded logger strings, not full-precision residuals or exact train-error counts.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/s05_dnn.log`
- SHA-256: `a5a58284e1670d13e0eb84d90ff25028ec2e6867e225d7496294c346dd0f3076`
- Locator: line 5, first completed width
- Scope: Display strings in the preserved log for the completed width rows.
- Limitations: A printed accuracy of 1.000 does not prove that every training row was correct, and a printed loss of 0.0000 is not a measured zero residual.

## LEG-MLP-PARTIAL-CURVE

On the completed validation rows, logged val_loss moves from 0.0063 at width 8 through 0.0020 at width 256 and is 0.0038 at width 512. Width 512 also has settled=False. This partial rounded validation series does not establish double descent: there is no completed later width showing a second decline, and the points are not a held-out test.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/s05_dnn.log`
- SHA-256: `a5a58284e1670d13e0eb84d90ff25028ec2e6867e225d7496294c346dd0f3076`
- Locator: line 17, width 512 result
- Scope: Rounded validation losses and settled flags printed for widths 8 through 512.
- Limitations: No confidence interval is computed. Settled is the historical logger flag, not a re-derived convergence certificate. The rise at one width is not a measured right-hand descent.

## LEG-MLP-NO-COMPLETED-1024

The preserved log starts width 1024 and has no completed metric line after that start line.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/s05_dnn.log`
- SHA-256: `a5a58284e1670d13e0eb84d90ff25028ec2e6867e225d7496294c346dd0f3076`
- Locator: line 18, final line of the snapshot
- Scope: The preserved log snapshot only.
- Limitations: Absence of a completion line does not identify why the run stopped and does not describe metrics that were never logged.

## LEG-MLP-NO-CHECKPOINT-FILES

The frozen directory listing for result/05_dnn records no child files. This audit did not open checkpoint payloads because none were listed.

- Disposition: `supported`
- Evidence: `research/stages/R1/inputs/dnn-directory-listing.json`
- SHA-256: `dd231e96add853e3385de8a89acebbd3fee872f16857f25c153f64a02adffabe`
- Locator: entries array
- Scope: One-level names and sizes of result/05_dnn at the listing time.
- Limitations: The listing does not search other directories and does not prove that a checkpoint was never written outside this path.

## LEG-PCA-CHOICE

pca_info.json records final_dims 4096 under the rule variance_target_not_met_within_cap. The same file records explained variance 0.8628636002540588 at 256 components against a 0.95 target.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/04_embedding_analysis/pca_info.json`
- SHA-256: `91f7f1f3319813959ddf445a67a45c3012ffa4208988007cef122ac073bb7d9c`
- Locator: line 8, final_dims
- Scope: The preserved PCA decision JSON.
- Limitations: The JSON does not by itself show that the reduced matrices contain 4096 columns. Those arrays were not hashed or opened.

## LEG-PARTIAL-META-768

The preserved partial_meta.json says dim 768, n_texts 464274, batch_size 32 and hash b84efb7dcf1eef7a. It does not contain backend or model keys.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/03_embeddings/partial_meta.json`
- SHA-256: `1c5d5a6eec5bcb36cff537632bade4d4efbd98694653ef743f24987090f1e63d`
- Locator: line 1
- Scope: Bytes of this one JSON object.
- Limitations: The current writer also emits backend and model. This audit did not execute that writer and did not read partial.dat, so 768 is not a measured width of the array.

## LEG-PROBE-4096

probe.json records model qwen/qwen3-embedding-8b, backend routerai and dim 4096. That dimension disagrees with partial_meta.json dim 768. The disagreement is between two small JSON files.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/03_embeddings/partials/routerai__qwen_qwen3-embedding-8b/probe.json`
- SHA-256: `d429b95986841a7e36d5c9b91cf61ba434386675a234b1479fee38072392f5ff`
- Locator: line 1
- Scope: The preserved probe JSON.
- Limitations: A probe of text_chars 4 does not certify the width of train.npy. The array was not read.

## LEG-CACHE-KEY-ENDPOINTS

The embedding cache key is computed from backend, model, batch size, text count, and SHA-256 prefixes of the first and last concatenated text. It does not hash every row or the internal order.

- Disposition: `supported`
- Evidence: `src/stages/s03_embeddings.py`
- SHA-256: `dcd0edc79736b0290b40f0b1b4576ad7fbe7abb895c05c289bba6da00a3beec1`
- Locator: line 276, first-text component
- Scope: Static reading of the current cache-key call. The stage was not executed.
- Limitations: Reading the key formula does not say whether the stored matrices match the current texts. A new key would not retroactively validate the old cache.

## LEG-CACHE-HASH-FUNCTION

compute_hash returns the first 16 hexadecimal characters of a SHA-256 over the sorted key-value strings. The code comment says the formula is frozen because a live run wrote it into partial_meta.json.

- Disposition: `supported`
- Evidence: `src/cache.py`
- SHA-256: `5d8c50598dba0cc26380bdc55ececd5a37d514a79bab3b17bf694d11ae6d1741`
- Locator: line 20
- Scope: Current helper source.
- Limitations: The helper was not executed against the historical texts in this audit.

## LEG-STAGE-CACHE-HASH

The preserved stage cache file records hash 6135da08b14f8ae4.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/03_embeddings/cache_hash.json`
- SHA-256: `8b9f0141a707adafd42524e803602943d41b9b0223af6db8ff42dab77e530082`
- Locator: line 1
- Scope: The 29-byte cache_hash.json snapshot.
- Limitations: The file does not identify which rows produced the hash.

## LEG-CACHE-HASH-MISMATCH

partial_meta.json hash b84efb7dcf1eef7a is not the hash recorded in cache_hash.json, 6135da08b14f8ae4. The partial metadata is therefore not the same record as the completed stage cache file.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/03_embeddings/partial_meta.json`
- SHA-256: `1c5d5a6eec5bcb36cff537632bade4d4efbd98694653ef743f24987090f1e63d`
- Locator: line 1, partial hash
- Scope: Comparison of two preserved JSON strings.
- Limitations: Neither string was recomputed from matrix bytes. The mismatch does not say which file, if either, matches train.npy.

## LEG-CACHE-RESUME-GUARD

The current resume predicate requires the partial hash, text count, backend, model, batch size and flag length to agree, and it raises if a matching partial dimension disagrees with the probe. This audit did not run that predicate.

- Disposition: `supported`
- Evidence: `src/stages/s03_embeddings.py`
- SHA-256: `dcd0edc79736b0290b40f0b1b4576ad7fbe7abb895c05c289bba6da00a3beec1`
- Locator: line 153
- Scope: Static reading of the current source.
- Limitations: A static reading is not an execution on the historical partial files.

## LEG-PILOT-NOT-CORPUS

The late-acceleration summary records embedding_corpus not_read and task_type CPU. It is not an observation about the essay embedding corpus.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/pilot_late_acceleration/summary.json`
- SHA-256: `30258445c78197fe7da960005db9f910cc0ed1a7f420b51e3010ff5c0b5b6ee6`
- Locator: line 5
- Scope: Fields in the preserved pilot summary.
- Limitations: The summary was not recomputed by rerunning the pilot.

## LEG-PILOT-H1-H4

In the preserved summary, H1 is inconclusive for the synthetic and breast-cancer blocks, and H4 records border_count, depth and ensemble_size as not_observed. The summary itself says a coarse peak is not double descent.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/pilot_late_acceleration/summary.json`
- SHA-256: `30258445c78197fe7da960005db9f910cc0ed1a7f420b51e3010ff5c0b5b6ee6`
- Locator: line 159, synthetic H4 note
- Scope: Verdict strings stored in the summary for this pilot.
- Limitations: These verdicts are the pilot's own labels. They are not a new hypothesis test and do not transfer to the essay corpus.

## LEG-SCOPE-EMBEDDINGGEMMA

The 4 November review says the inputs are frozen EmbeddingGemma embeddings. The preserved probe names qwen/qwen3-embedding-8b. The two texts do not describe the same embedder.

- Disposition: `supported`
- Evidence: `reviews/04-11-2026.md`
- SHA-256: `6e9365cc4cc4c5786f36844fdf6c788b4b42252e0d878aa9150ebf7a8724e200`
- Locator: line 128
- Scope: One sentence of the historical review, contrasted with the preserved probe JSON.
- Limitations: The review sentence is not a measurement of the matrix. The matrix bytes remain unread.

## LEG-SCOPE-PROTOCOL

The 4 November protocol revision records that s03 uses qwen/qwen3-embedding-8b at 4096 dimensions through RouterAI, that the review discusses EmbeddingGemma, and that the embedder was not switched.

- Disposition: `supported`
- Evidence: `docs/protocol_revision_2026-11-04.md`
- SHA-256: `0cb07912f7ce2eda68cccfd52903c11ef33d928b22632c01237ec3fb5a45ad2b`
- Locator: line 54
- Scope: The historical protocol note.
- Limitations: This is a dated project note, not an independent remeasurement of the embeddings.

## LEG-SCOPE-CPU

The preserved MLP log records Device: cpu and noise_regime=clean. That is the logged regime of this snapshot, not a description of every earlier plan.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/result/s05_dnn.log`
- SHA-256: `a5a58284e1670d13e0eb84d90ff25028ec2e6867e225d7496294c346dd0f3076`
- Locator: line 3
- Scope: The device line and the clean noise labels in this log.
- Limitations: The log does not quote the older preregistration. A CPU/clean log does not audit a GPU or noisy arm that is not in the log.

## LEG-SOURCE-MANIFEST

source_manifest.json names the Hugging Face mirror andythetechnerd03/AI-human-text and says the processed mirror is not a byte copy of the Kaggle CSV. It records 487235 rows written.

- Disposition: `supported`
- Evidence: `research/evidence/legacy-2026-11-07/files/data/source_manifest.json`
- SHA-256: `00089f0094277cbc097f23cada04e572f934108fb1cc1b5932b4a2e37f369a73`
- Locator: line 3
- Scope: The preserved source-manifest text.
- Limitations: The manifest's parquet hashes were not recomputed. Split membership, near-duplicate leakage and row order were not assessed.

## LEG-EMB-TRAIN-UNHASHED

Inventory records result/03_embeddings/train.npy as local-only, 5324652672 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/03_embeddings/train.npy`
- SHA-256: `None`
- Locator: inventory entry result/03_embeddings/train.npy
- Scope: Recorded byte size only.
- Limitations: Size does not establish dimension, row order, model identity or any risk curve.

## LEG-EMB-VAL-UNHASHED

Inventory records result/03_embeddings/val.npy as local-only, 1140998272 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/03_embeddings/val.npy`
- SHA-256: `None`
- Locator: inventory entry result/03_embeddings/val.npy
- Scope: Recorded byte size only.
- Limitations: Size does not establish dimension, row order or agreement with the validation labels.

## LEG-EMB-TEST-UNHASHED

Inventory records result/03_embeddings/test.npy as local-only, 1141014656 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/03_embeddings/test.npy`
- SHA-256: `None`
- Locator: inventory entry result/03_embeddings/test.npy
- Scope: Recorded byte size only.
- Limitations: The test matrix cannot support a held-out claim until its bytes and row map are attested.

## LEG-EMB-PARTIAL-UNHASHED

Inventory records result/03_embeddings/partial.dat as local-only, 1426249728 bytes, with no content hash. This audit did not read or hash the file.

- Disposition: `not_assessed`
- Evidence: `result/03_embeddings/partial.dat`
- SHA-256: `None`
- Locator: inventory entry result/03_embeddings/partial.dat
- Scope: Recorded byte size only.
- Limitations: The partial file is not evidence of a finished embedding or of the 768-versus-4096 metadata conflict.

## LEG-SPLIT-PARQUET-UNHASHED

Inventory records result/01_data/train.parquet as local-only, 371212707 bytes, with no content hash. This audit did not read or hash the split.

- Disposition: `not_assessed`
- Evidence: `result/01_data/train.parquet`
- SHA-256: `None`
- Locator: inventory entry result/01_data/train.parquet
- Scope: Recorded byte size only.
- Limitations: Row order, duplicate structure and label alignment remain unassessed.

## LEG-SPLIT-VAL-UNHASHED

Inventory records result/01_data/val.parquet as local-only, 79406596 bytes, with no content hash. This audit did not read or hash the split.

- Disposition: `not_assessed`
- Evidence: `result/01_data/val.parquet`
- SHA-256: `None`
- Locator: inventory entry result/01_data/val.parquet
- Scope: Recorded byte size only.
- Limitations: Validation rows were not audited for leakage or alignment.

## LEG-SPLIT-TEST-UNHASHED

Inventory records result/01_data/test.parquet as local-only, 79511717 bytes, with no content hash. This audit did not read or hash the split.

- Disposition: `not_assessed`
- Evidence: `result/01_data/test.parquet`
- SHA-256: `None`
- Locator: inventory entry result/01_data/test.parquet
- Scope: Recorded byte size only.
- Limitations: The historical test split is not an untouched confirmation set for a new hypothesis.

## LEG-REDUCED-TRAIN-UNHASHED

Inventory records result/04_embedding_analysis/train_reduced.npy as local-only, 5328552564 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/04_embedding_analysis/train_reduced.npy`
- SHA-256: `None`
- Locator: inventory entry result/04_embedding_analysis/train_reduced.npy
- Scope: Recorded byte size only.
- Limitations: final_dims in pca_info.json is not a substitute for the array header.

## LEG-REDUCED-VAL-UNHASHED

Inventory records result/04_embedding_analysis/val_reduced.npy as local-only, 1141833964 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/04_embedding_analysis/val_reduced.npy`
- SHA-256: `None`
- Locator: inventory entry result/04_embedding_analysis/val_reduced.npy
- Scope: Recorded byte size only.
- Limitations: No column count or row map was read.

## LEG-REDUCED-TEST-UNHASHED

Inventory records result/04_embedding_analysis/test_reduced.npy as local-only, 1141850360 bytes, with no content hash. This audit did not read or hash the array.

- Disposition: `not_assessed`
- Evidence: `result/04_embedding_analysis/test_reduced.npy`
- SHA-256: `None`
- Locator: inventory entry result/04_embedding_analysis/test_reduced.npy
- Scope: Recorded byte size only.
- Limitations: No held-out risk can be computed from the recorded size.
